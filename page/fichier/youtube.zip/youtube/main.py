from pytube import YouTube
import ffmpeg
BASE_YOUTUBE_URL = "https://www.youtube.com"
BASE_YOUTUBE_URL2 = "https://youtu.be"
#---
def get_video_url_from_user():
    url = input("Donnez l'url de la vidéo Youtube à télécharger: ")
    #if url[:len(BASE_YOUTUBE_URL)] == BASE_YOUTUBE_URL:
    if url.lower().startswith(BASE_YOUTUBE_URL) or url.lower().startswith(BASE_YOUTUBE_URL2):
        pass
    else:    
        print("ERREUR : Vous devez rentrer une URL de video Youtube")
        return get_video_url_from_user()

    try:
        youtube_video = YouTube(url)
        print("TITRE: " + youtube_video.title)
        print("NB VUES:", youtube_video.views)
    except:
        print("ERREUR donner une vrai url youtube")
        return get_video_url_from_user()
    return youtube_video
    
def get_video_stream_itag_from_user(streams):
    print("CHOIX DES RÉSOLUTIONS")
    index = 1
    for stream in streams:
        print(f"{index} - {stream.resolution}")
        index += 1

    while True:
        res_num = input("Choisissez la résolution: ")
        if res_num == "":
            print("ERREUR : Vous devez rentrer un nombre")
        else:
            try:
                res_num_int = int(res_num)
            except:
                print("ERREUR : Vous devez rentrer un nombre")
            else:
                if not 1 <= res_num_int <= len(streams):
                    print("ERREUR : Vous devez rentrer un nombre entre 1 et", len(streams))
                else:
                    break

    itag = streams[res_num_int-1].itag
    return itag

def on_download_progress(stream, chunk, bytes_remaining):
    bytes_downloaded = stream.filesize - bytes_remaining
    percent = bytes_downloaded * 100 / stream.filesize

    print(f"Progression du téléchargement {int(percent)}%")


url = "https://www.youtube.com/watch?v=9bZkp7q19f0"
# youtube_video = get_video_url_from_user()
youtube_video = YouTube(url)
print("TITRE: " + youtube_video.title)
print("NB VUES:", youtube_video.views)


# vérifier que l'url commence par "https://www.youtube.com"
# si ce n'est pas le cas 
# - afficher une erreur
# - reposer la question




youtube_video.register_on_progress_callback(on_download_progress)



print("")

print("STREAMS")
streams = youtube_video.streams.filter(progressive=False, file_extension='mp4', type="video").order_by("resolution").desc()
video_stream = streams[0]

streams = youtube_video.streams.filter(progressive=False, file_extension='mp4', type="audio").order_by("abr").desc()
audio_stream = streams[0]

print("video stream : ", video_stream)
print("audio stream : ", audio_stream)


# for stream in streams:
#     print(stream)
# itag = get_video_stream_itag_from_user(streams)

# print("itag: ", itag)
# 1 - 360p
# 2 - 720p
# Choisissez la résolution: 
# stream.resolution
# stream.itag

# Demander le choix de la résolution


stream = youtube_video.streams.get_by_itag()
# stream = youtube_video.streams.get_highest_resolution()
# print("Steam vidéo: ", stream)
print("Téléchargement video...")
stream.download("video")
print("OK")

print("Téléchargement audio...")
stream.download("audio")
print("OK")

